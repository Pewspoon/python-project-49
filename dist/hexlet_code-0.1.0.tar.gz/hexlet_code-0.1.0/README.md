### Hexlet tests and linter status:
https://asciinema.org/a/wwF6Sb9WcU2kOK5y4O9ZoEHnp - brain-even
https://asciinema.org/a/EwQ1IfR8ZEpehMKK8CQ2g3tli - brain-calc
https://asciinema.org/a/1OagKOQiOVYoqHuYVNM3QG3QW - brain-gcd
https://asciinema.org/a/NeZrctYQmexHQJyoTQxkBt1sq - brain-progression
https://asciinema.org/a/eweGPupW8z3R5ZLUy6o8pdcKp - brain-prime 
[![Actions Status](https://github.com/Pewspoon/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Pewspoon/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/42c86a4969edd0e7b9c9/maintainability)](https://codeclimate.com/github/Pewspoon/python-project-49/maintainability)